
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.Arrays;

import Application.DHCPApplication;
import Application.DNSApplication;
import Application.FTPClient;
import Application.HPingApp;
import Application.HTTPClient;
import Application.HTTPPostClient;
import Application.PingApp;
import Application.TCPRawDataSender;
import Application.TCPThreeHandShakes;
import Application.TFTPClient;
import Application.TraceRoute;
import datalinklayer.DataLinkLayer;
import jpcap.JpcapCaptor;
import jpcap.JpcapSender;
import jpcap.NetworkInterface;
import jpcap.NetworkInterfaceAddress;
import jpcap.packet.ARPPacket;
import jpcap.packet.EthernetPacket;
import jpcap.packet.IPPacket;
import jpcap.packet.TCPPacket;


public class ProtocolEntry {
	
	public static void main(String[] args) throws IOException {
		 NetworkInterface[] devices = JpcapCaptor.getDeviceList();
		    NetworkInterface device = null;    
		    System.out.println("there are " + devices.length +  " devices");
		 
		    for (int i = 0; i < devices.length; i++) {
		    	
		         boolean findDevice = false;   
		         for (NetworkInterfaceAddress addr  : devices[i].addresses) {
		             //网卡网址符合ipv4规范才是可用网卡
		             if (!(addr.address instanceof Inet4Address)) {
		                  continue;
		             }
		        	 
		        	 System.out.println("device name: " + devices[i].name);		            
		             findDevice = true;
		             
		             break;
		         }
		            
		         if (findDevice) {
		              device = devices[i];
		              break;
		         }
		            
		   }
		    
		   JpcapCaptor jpcap = JpcapCaptor.openDevice(device, 2000, true, 20);
		   
		   DataLinkLayer linkLayerInstance = DataLinkLayer.getInstance();
		   linkLayerInstance.initWithOpenDevice(device);
		   
		   try {
			   HTTPPostClient  http_client = new HTTPPostClient();
			   http_client.run();
		   } catch(Exception e) {
			   e.printStackTrace();
		   }
		   
		   jpcap.loopPacket(-1, (jpcap.PacketReceiver) linkLayerInstance);
	  
  } //main(...)
}
