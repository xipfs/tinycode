package utils;

public interface IFTPDataReceiver {
    public void receive_ftp_data(byte[] data);
}
